import rasm1 from "../../assents/imgs/44.jpg"
import rasm2 from "../../assents/imgs/43.jpg"
import rasm3 from "../../assents/imgs/42.jpg"
import rasm4 from "../../assents/imgs/41.jpg"
import rasm5 from "../../assents/imgs/40.jpg"
// import rasm4 from "../../assents/imgs/45.png"


export const Blogmap = [
    {
        id: '1',
        name: "5 приспособлений, которые улучшат поездку",
        rasm: rasm1
    },
    {
        id: '2',
        name: "15 отличных велотуров по Европе",
        rasm: rasm2
    },
    {
        id: '3',
        name: "Руководство по долгим велопрогулкам",
        rasm: rasm3
    },
    {
        id: '4',
        name: "Города, в которых любят велосипедистов",
        rasm: rasm4
    },
    {
        id: '5',
        name: "Абсолютная свобода движений",
        rasm: rasm5
    },

]