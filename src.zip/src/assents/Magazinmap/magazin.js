export const MagazinMap = [
    {
        img: "https://static.wixstatic.com/media/1e47b2_8744fed3fccb4048854021ff87959874.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_8744fed3fccb4048854021ff87959874.jpg",
        narx:"2 000,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_832b0bb8d00d4239a45c78ffc5060194.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_832b0bb8d00d4239a45c78ffc5060194.jpg",
        narx: "2 500,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_3d945b9c0e9643719a8659871818e5f1.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_3d945b9c0e9643719a8659871818e5f1.jpg",
        narx:"2 300,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_d8a090077f714ffd99db556780b2b5d2.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_d8a090077f714ffd99db556780b2b5d2.jpg",
        narx:"2 000,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_d0ae09b5ddb44af8a269ba6952f4a8e2.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_d0ae09b5ddb44af8a269ba6952f4a8e2.jpg",
        narx:"1 800,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_b1a46e07fe9e420aa109606054ff72b6.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_b1a46e07fe9e420aa109606054ff72b6.jpg",
        narx:"2 660,00 ₽",
        narx2:"2 800,00 ₽",
        skit:"5",
        opa:"1"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_8f0813203b9a4acab38cae18aa5ebf61.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_8f0813203b9a4acab38cae18aa5ebf61.jpg",
        narx:"2 070,00 ₽",
        narx2:"2 300,00 ₽",
        skit:"10",
        opa:"1"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_224b87a66088497a9987098540047a20.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_224b87a66088497a9987098540047a20.jpg",
        narx:"2 200,00 ₽",
        opa:"0"
    },
    {
        img:"https://static.wixstatic.com/media/1e47b2_d767f9b2959c426b9eaf5c7c4d421a3b.jpg/v1/fill/w_267,h_178,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1e47b2_d767f9b2959c426b9eaf5c7c4d421a3b.jpg",
        narx:"2 500,00 ₽",
        opa:"0"
    }
   
]
